export class TableCell {
    content: any;

    constructor(content: any) {
        this.content = content;
    }
}
